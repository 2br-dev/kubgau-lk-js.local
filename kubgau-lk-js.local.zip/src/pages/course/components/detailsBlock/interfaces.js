export let EView

;(function(EView) {
  EView[(EView["TABLE"] = 0)] = "TABLE"
  EView[(EView["CARD"] = 1)] = "CARD"
})(EView || (EView = {}))
