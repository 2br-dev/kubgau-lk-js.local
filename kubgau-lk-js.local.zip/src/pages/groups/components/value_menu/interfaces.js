export let EMenuType

;(function(EMenuType) {
  EMenuType[(EMenuType["CREATE"] = 0)] = "CREATE"
  EMenuType[(EMenuType["UPDATE"] = 1)] = "UPDATE"
})(EMenuType || (EMenuType = {}))
