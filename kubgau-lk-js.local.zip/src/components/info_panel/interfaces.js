export let InfoClass

;(function(InfoClass) {
  InfoClass["INFO"] = "info"
  InfoClass["WARNING"] = "warning"
  InfoClass["ERROR"] = "error"
})(InfoClass || (InfoClass = {}))
